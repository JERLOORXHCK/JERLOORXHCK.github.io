# JERLOORXHCK GitHub Pages Website

## Included
- Responsive JERLOORXHCK landing page using the supplied logo image.
- English service/activity section.
- Email and WhatsApp contact buttons.
- Real Supabase email/password registration and login.
- Dashboard shown after authentication.
- Supabase profile table + Row Level Security SQL.

## Supabase setup
1. Open your Supabase project.
2. Go to **SQL Editor**.
3. Run `supabase.sql`.
4. In **Authentication -> URL Configuration**, add your GitHub Pages URL as a Site URL / Redirect URL, for example:
   `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`
5. If email confirmation is enabled, users must confirm their email before they can log in.

The website uses the Supabase **publishable** key in the browser. Do NOT put a secret/service-role key in `index.html`.

## GitHub Pages
1. Create/open your repository.
2. Upload `index.html`, `logo.png`, and `supabase.sql`.
3. Commit the files.
4. Go to **Settings -> Pages**.
5. Select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
6. Open the generated GitHub Pages URL in Chrome.

## Contact
Email: jerloorking@gmail.com
WhatsApp: https://wa.me/2347070783758
